<?php
session_start();

   require 'config.php';
 if(isset($_POST['login']))
 {
  $user=$_POST['email'];
  $pass=$_POST['password'];
  $str="select pass,pnum from user where email='$user'";
  $result = mysqli_query($conn, $str);
   if (mysqli_num_rows($result) > 0)
            {
                while($row = mysqli_fetch_assoc($result))
                {
				  $pas=$row['pass'];
                  $p=$row['pnum'];				  
				}
			}
			if(strcmp($pass,$pas)==0)
			{
				echo"in";
				echo "<script>alert('Login Successful'); 
	                location.replace('home.php');
					</script>";
					setcookie('user',1);
					setcookie('p',$p);
					setcookie('time',date('Y-m-d h:i:s a', time()+4*3600));
			}
			else
			{
				echo "<script>alert('Wrong email or Password'); 
	                location.replace('login.php');
					</script>";
			}
 }
?>