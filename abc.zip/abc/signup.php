<!DOCTYPE html>
<html>
    <head>
        <title>Sign Up</title>
    </head>
    <script>
        function limit(element)
{
    var max_chars = 8;
    var x;
    if(element.value.length > max_chars) {
        document.getElementById('ph').value=x;
        alert("please enter 8 digit only");
    }
   
}
        function nlink()
        {
            location.replace("login.php");
            
        }
    </script>
    <body>
        
        <form action ="user.php" method="POST">
            <fieldset style="width:400px;margin-left:450px;margin-top:100px;border-radius:5px">
                <legend><h2 style="color: darkcyan"><i>Registration</i></h2></legend>
                <table>
                    <tr>
                        <td>First Name</td>
                        <td><input type="text" id="f" placeholder="" name="fName" size="27"></td>
                    </tr>
                    <tr>
                        <td>Last Name</td>
                        <td><input type="text" name="lName" size="27"></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td><input type="text" name="email" size="27"></td>
                    </tr>
                     <tr>
                        <td>Phone Number</td>
                        <td>
                            <select name="ip">
                                <option>015</option>
                                <option>016</option>
                                <option>017</option>
                                <option>018</option>
                                <option>019</option>
                            </select><input type="number" name="phoneNumber" max="99999999" id="ph" size="7" onkeyup="limit(this)"></td>
                    </tr>
                     <tr>
                        <td>Password</td>
                        <td><input type="password" name="password" size="27"></td>
                    </tr>
                     <tr>
                        <td>Confirm Password</td>
                        <td><input type="password" name="cp" size="27"></td>
                    </tr>
                    <tr>
                        <td>Gender</td>
                        <td><input type="radio" name="male">Male
                            <input type="radio" name="female">Female
                            <input type="radio" name="other">Other
                        </td>
                    </tr>
                    <tr>
                        <td>Date of Birth</td>
                        <td><input type="date" name="dob" size="27"></td>
                    </tr>
                    <tr>
                        <td><input type="submit" value="Register" name="signup">&nbsp;&nbsp;
                            <input type="button" value="Reset" name="reset"></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Already have an account?</td>
                        <td><input type="button" name="login" value="Login" onclick="nlink()"></td>
                    </tr>
                </table>
            </fieldset>
        </form>
    </body>
</html>