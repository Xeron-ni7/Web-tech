<?php
  require 'config.php';
    $fname=$_POST['fName'];
	$lname=$_POST['lName'];
	$email=$_POST['email'];
	$pass=$_POST['password'];
	$dob=$_POST['dob'];
	$phone=$_POST['ip'].$_POST['phoneNumber'];
   $statement="insert into user (fname,name,email,pass,dob,pnum) 
               values('$fname','$lname','$email','$pass','$dob','$phone');";
   $result = mysqli_query($conn, $statement);
  if($result==1)
  {
	  echo "<script>alert('Registration Successful'); 
	                location.replace('home.php');
					</script>";
  }
   

?>