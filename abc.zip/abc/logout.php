<?php
include("config.php");
  $time=$_COOKIE['time'];
  $p=$_COOKIE['p'];
  setcookie('user',0);
  $date=date('Y-m-d h:i:s a', time()+4*3600);
  if(mysqli_query($conn,"UPDATE user SET login='$time',logout='$date' WHERE pnum='$p'"))
{
	echo $p;
  header('Location:viewdata.php?msg="You are logged out."');

}
else
    mysqli_error($conn);

mysqli_close($conn);
  
 ?>