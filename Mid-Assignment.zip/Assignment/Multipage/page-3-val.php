<?php
  
//validation function for text field...........................

 function validation1($fieldName,$value,$name) {
 	  global  $hasValue3;
 	 if(trim($value)=="" || preg_match('[^a-zA-Z0-9]',$value))
 	 {
 	 	error_flag1($fieldName,$value);
 	 	$hasValue3[$name]=0;
 	 }
 	 else {
 	 	$hasValue3[$name]=1;
 	 	setcookie($name,$value);
 	 }
 	}
 	
//error flag function for text field...........................

 function error_flag1($fieldName,$value) {
	global $errors3;
	$errorString="please enter valid ".$fieldName;
	
	$errors3[]=$errorString;
 } 	

//validation function for select field.........................

 function validation2($fieldName,$value,$name) {
 	global $hasValue3;
 	if(trim($value)=='-SELECT-' || trim($value)=="")
 	{
 		
 		error_flag2($fieldName,$value);
 		$hasValue3[$name]=0;
 	}
 	 else {
 	 	$hasValue3[$name]=1;
 	 	setcookie($name,$value);
 	 }
 }


//error flag function for select field...........................

 function error_flag2($fieldName,$value) {
   global $errors3;
	$errorString="please select a ".$fieldName;
	$errors3[]=$errorString;
 } 	
 
 
 function validation3($value,$name) {
 	global $hasValue3;
 		if(trim($value)=='-SELECT-' || trim($value)=="")
 	{
 		$hasValue3[$name]=0;
 	}
 	 else {
 	 	$hasValue3[$name]=1;
 	 	setcookie($name,$value);
 	 }
 }
 
  $p=& $_POST;
  
  
  validation1('Receipt No',$p['reNo'],'reNo');
  validation1('Amount',$p['money'],'money');
  validation3($p['tk'],'tk');
  validation3($p['bank'],'bank');
  validation3($p['branch'],'branch');
  
  if(empty($p['pDate']))
  {
     error_flag1('Payment Date','001');
     $hasValue3['pDate']=0;  	
  }
  else {
  	$hasValue3['pDate']=1;
  	setcookie('pDate',$p['pDate']);
  }
  
    
   setcookie('hasValue3',json_encode($hasValue3));

   if (count($errors3)>0)
   {
   	$ew="fieldError3";

   setcookie($ew,json_encode($errors3));
  // setcookie('check',json_encode($fieldsOfError));
	
  }
  else {
  	setcookie("fieldError3", "", time() - 3600);
  }
  header('Location: http://localhost/Assignment/Multipage/Final-stage.php');
  
?>