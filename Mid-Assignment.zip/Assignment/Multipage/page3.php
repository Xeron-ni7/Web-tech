<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Passport Application Part-3</title>
	 <link rel="stylesheet" href="page_1_Style.css">
</head>
<script type="text/javascript">
 function nlink()
        {
            location.replace("http://localhost/Assignment/Multipage/page2.php");
            
        }
</script>
<body>
	<div class="">
		<h3>PASSPORT APPLICATION - STAGE 3</h3>
	    <p style="color:navy">Online application ID: OA0000004008216</p>
	    <p>Fields marked with <span style="color:red">(*)</span> are mendatory.</p>
	<hr>
	    <!-----php code -->
        <?php
        if(isset($_COOKIE['fieldError3']))
        {
          $e=json_decode($_COOKIE['fieldError3'],true);
          $i=count($e);
          echo "<fieldset style='background-color:gray'>";
          for($j=0;$j<$i;$j++)
          {
            echo "<font color='red'>*</font> $e[$j] </br>";
          }
          echo "</fieldset>";
        }
        if(isset($_COOKIE['hasValue3'])) {
        	 $hasValue3=json_decode($_COOKIE['hasValue3'], true);
        }
        else {
        	$hasValue3=0;
        }
       ?>
        <!-- php code end here -->

		<form action="page-3-val.php"method="POST" accept-charset="utf-8">
		<fieldset>
			<table style="width:50%; float:left; border-right:1px dotted black; border-spacing:8px;">
				<tr>
					<td><h3 style="color:navy">Payment Information</h3></td>
				</tr>
				<tr>
					<td>Payment Type:</td>
					<td>
						<input type="radio" name="#">Online <br>
						<input type="radio" name="#" checked>Non-Online 
					</td>
				</tr>
				<tr>
					<td><input type="checkbox" name="#"> Skip Payment </td>
				</tr>
				<tr>
					<td>Amount:<span style="color:red">*</span></td>
					<td>
						<select name="tk" style="width:60px" id="#" value="">
							<option><?php if($hasValue3!=0)
                                      {
                                      	if($hasValue3['tk']==1) echo $_COOKIE['tk'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
							<option selected>BDT</option>
							<option>DOLLER</option>
							<option>RUPI</option>
							<option>EURO</option>
						</select>
						<input type="text" name="money" class="input" style="width:180px;" value="<?php if($hasValue3!=0)
                                      {
                                      	if($hasValue3['money']==1) echo $_COOKIE['money'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
					</td>
				</tr>
				<tr>
					<td>Date of Payment:<span style="color:red">*</span></td>
					<td><input type="date" name="pDate" class="input" value="<?php if($hasValue3!=0)
                                      {
                                      	if($hasValue3['pDate']==1) echo $_COOKIE['pDate'];
                                       else echo '';
                                       }
                                        else echo '';  ?>"></td>
				</tr>
				<tr>
					<td>Receipt No: <span style="color:red">*</span></td>
					<td><input type="text" name="reNo" class="input" value="<?php if($hasValue3!=0)
                                      {
                                      	if($hasValue3['reNo']==1) echo $_COOKIE['reNo'];
                                       else echo '';
                                       }
                                        else echo '';  ?>"></td>
				</tr>
				<tr>
					<td> Name of Bank:</td>
					<td>
						<select name="bank" id="#" value="">
                        	<option selected><?php if($hasValue3!=0)
                                      {
                                      	if($hasValue3['bank']==1) echo $_COOKIE['bank'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                        	<option>FSIBL</option>
                        	<option>DBBL</option>
                        	<option>ISBL</option>
                        	<option>AB BANK</option>
                        	<option>BANK ASIA</option>
                        </select>
					</td>
				</tr>
				<tr>
					<td> Name of Branch:</td>
					<td>
						<select name="branch" id="#" value="">
                        	<option selected><?php if($hasValue3!=0)
                                      {
                                      	if($hasValue3['branch']==1) echo $_COOKIE['branch'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                        	<option>BANANI BRANCH</option>
                        	<option>GULSAN BRANCH</option>
                        	<option>BASHUNDHARA BRANCH</option>
                        	<option>CHAWKBAZAR BRANCH</option>
                        </select>
					</td>
				</tr>
			</table>
			<!-- 2nd table Start -->
			<table style="width:20%; float:left; border-spacing:2px;">
				<tr>
					<td> <input type="button" name="#" value="PREVIOUS PAGE" onclick="nlink()"></td>
					<td><input type="submit" name="#" value="SAVE & NEXT"></td>
				</tr>
			</table>
		</fieldset>	
		</form>
	</div>
</body>
</html>
