<?php

//validation function for text field...........................

 function validation1($fieldName,$value,$name) {
 	  global  $hasValue;
 	 if(trim($value)=="" || preg_match('[^a-zA-Z]',$value))
 	 {
 	 	error_flag1($fieldName,$value);
 	 	$hasValue[$name]=0;
 	 }
 	 else {
 	 	$hasValue[$name]=1;
 	 	setcookie($name,$value);
 	 }
 	}
 	
//error flag function for text field...........................

 function error_flag1($fieldName,$value) {
	global $errors;
	$errorString="please enter valid ".$fieldName;
	
	$errors[]=$errorString;
 } 	

//validation function for select field.........................

 function validation2($fieldName,$value,$name) {
 	global $hasValue;
 	if(trim($value)=='-SELECT-' || trim($value)=="")
 	{
 		
 		error_flag2($fieldName,$value);
 		$hasValue[$name]=0;
 	}
 	 else {
 	 	$hasValue[$name]=1;
 	 	setcookie($name,$value);
 	 }
 }


//error flag function for select field...........................

 function error_flag2($fieldName,$value) {
   global $errors;
	$errorString="please select a ".$fieldName;
	$errors[]=$errorString;
 } 	
 
 
 function validation3($value,$name) {
 	global $hasValue;
 		if(trim($value)=='-SELECT-' || trim($value)=="")
 	{
 		$hasValue[$name]=0;
 	}
 	 else {
 	 	$hasValue[$name]=1;
 	 	setcookie($name,$value);
 	 }
 }

//values .......................................

 $p=& $_POST;
 validation3($p['applyin'],'applyin');
 validation3($p['passType'],'passType');

 //$p['delType'];

 validation3($p['fName'],'fName');
 validation3($p['faNationality'],'faNationality');
 validation3($p['mNationality'],'mNationality');
 validation3($p['spName'],'spName');
 validation3($p['spNationality'],'spNationality');
 validation3($p['spjob'],'spjob');
 validation3($p['cob'],'cob');
 validation3($p['dob'],'dob');

// $p['gender'];

 validation3($p['nid'],'nid');
 validation3($p['tid'],'tid');
 validation3($p['nationality'],'nationality');
 validation3($p['ctStatus'],'ctStatus');

// $p['dualct'];

 validation3($p['pVH'],'pVH');
 validation3($p['pRoad'],'pRoad');
 validation3($p['pDist'],'pDist');
 validation3($p['paVH'],'paVH');
 validation3($p['paRoad'],'paRoad');
 
 
 $height=$p['cm']+$p['inch'];
 
 //validation check for text field..............
 
   validation1('Name',$p['name'],'name');//applicant name check
   
   validation1('Surname',$p['sName'],'sName');//applicant surname check
   
   validation1('Father\'s Name',$p['faName'],'faName');//applicant father's name check
   
    validation1('Mother\'s Name',$p['mName'],'mName');//applicant mother's name check
   
   validation1('Birth Id',$p['bid'],'bid');//applicant birth id check
   
   validation1('Height',$height,'height');//applicant height check
   
   validation1('Email', $p['email'],'email');//applicant email check
  

// validation check for selection items.................

  validation2('Father\'s profession',$p['fajob'],'fajob');//applicant father's job check
  
  validation2('Mother\'s profession',$p['mjob'],'mjob');//applicant mother's job check

  validation2('Marital Status',$p['mStatus'],'mStatus');//applicant martial status check

  validation2('Your profession',$p['job'],'job');//applicant job check

  validation2('Your District',$p['bdist'],'bdist');//applicant district check

  validation2('Birth Id',$p['bid'],'bid');//applicant birth id check

  validation2('Religion',$p['religion'],'religion');//applicant religion check

  validation2('Police Station',$p['pPST'],'pPST');//applicant present police station  check

  validation2('Post Office',$p['pPO'],'pPO');//applicant present post office check

  validation2('Permanent District',$p['paDist'],'paDist');//applicant permanent district check

  validation2('Permanent Police Station',$p['paPST'],'paPST');//applicant permanent police station check

  validation2('Permanent Post Office',$p['paPO'],'paPO');//applicant permanent post office check

  setcookie('hasValue',json_encode($hasValue));
  
  if(empty($p['dob']))
  {
     error_flag1('Date of birth','001');
     $hasValue1['dob']=0;  	
  }
  else {
  	$hasValue1['dob']=1;
  	setcookie('dob',$p['dob']);
  }
  

   if (count($errors)>0)
   {
   	$ew="fieldError";

   setcookie($ew,json_encode($errors));
  // setcookie('check',json_encode($fieldsOfError));
 	header('Location: http://localhost/Assignment/Multipage/page1.php');
  }
  else {
  	setcookie("fieldError", "", time() - 3600);
  }
  header('Location: http://localhost/Assignment/Multipage/page2.php');
?>