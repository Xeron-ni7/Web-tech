<?php
//validation function for text field...........................

 function validation1($fieldName,$value,$name) {
 	  global  $hasValue2;
 	 if(trim($value)=="" || preg_match('[^a-zA-Z]',$value))
 	 {
 	 	error_flag1($fieldName,$value);
 	 	$hasValue2[$name]=0;
 	 }
 	 else {
 	 	$hasValue2[$name]=1;
 	 	setcookie($name,$value);
 	 }
 	}
 	
//error flag function for text field...........................

 function error_flag1($fieldName,$value) {
	global $errors2;
	$errorString="please enter valid ".$fieldName;
	
	$errors2[]=$errorString;
 } 	

//validation function for select field.........................

 function validation2($fieldName,$value,$name) {
 	global $hasValue2;
 	if(trim($value)=='-SELECT-' || trim($value)=="")
 	{
 		
 		error_flag2($fieldName,$value);
 		$hasValue2[$name]=0;
 	}
 	 else {
 	 	$hasValue2[$name]=1;
 	 	setcookie($name,$value);
 	 }
 }


//error flag function for select field...........................

 function error_flag2($fieldName,$value) {
   global $errors2;
	$errorString="please select a ".$fieldName;
	$errors2[]=$errorString;
 } 	
 
 
 function validation3($value,$name) {
 	global $hasValue2;
 		if(trim($value)=='-SELECT-' || trim($value)=="")
 	{
 		$hasValue2[$name]=0;
 	}
 	 else {
 	 	$hasValue2[$name]=1;
 	 	setcookie($name,$value);
 	 }
 }
 
  $p=& $_POST;
 
 validation1('Emergency person name.',$p['emName'],'emName');
 validation1('Emergency person contact no.',$p['emCon'],'emCon');
 validation2('Emergency person District.',$p['emDist'],'emDist');
 validation2('Emergency person Police Station.',$p['emPST'],'emPST');
 validation2('Emergency person Post office. ',$p['emPO'],'emPO');
 validation2('Emergency person Relation with you.',$p['emRel'],'emRel');
 
 validation3( $p['ofNo'],'ofNo');
 validation3( $p['reNo'],'reNo');
 validation3( $p['emVH'],'emVH');
  validation3( $p['emRoad'],'emRoad');
   validation3( $p['emEmail'],'emEmail');
  validation3( $p['emPassNo'],'emPassNo');
   validation3( $p['rIs'],'rIs');
    validation3( $p['emCountry'],'emCountry');
   validation3( $p['pIs'],'pIs');
   
   validation3( $p['rIs'],'rIs');     
    $pd=$p['nt'];
     
     echo $p['nt'];
    $pln=strlen((string)$p['phoneNumber']);
    if($p['phoneNumber']!=0 && $pln=8 )
    {
    	$pn=$pd.$p['phoneNumber'];
    	 $hasValue2['pn']=1;
 	 	setcookie('pn',$pn);
      
      $hasValue2['pd']=1;
 	 	setcookie('pd',$pd);
 	 	echo $pd;   
    	
    	$hasValue2['ppn']=1;
 	 	setcookie('ppn',$p['phoneNumber']);
    	
    }
    else {
    	 $hasValue2['pd']=0;
    	 $hasValue2['ppn']=0;
    	error_flag1('phone number','jk');
    }
    
    if(empty($p['dIs']))
  {
     error_flag1('Date of issue','001');
     $hasValue2['dIs']=0;  	
  }
  else {
  	$hasValue2['dIs']=1;
  	setcookie('dIs',$p['dIs']);
  }
      
    
    
    
   setcookie('hasValue2',json_encode($hasValue2));

   if (count($errors2)>0)
   {
   	$ew="fieldError2";

   setcookie($ew,json_encode($errors2));
  // setcookie('check',json_encode($fieldsOfError));
	
  }
   else {
  	setcookie("fieldError2", "", time() - 3600);
  }
 
 header('Location: http://localhost/Assignment/Multipage/page3.php');
?>