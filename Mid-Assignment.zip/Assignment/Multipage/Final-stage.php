<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Final Stage</title>
	<link rel="stylesheet" href="">
</head>
<script type="text/javascript">
function nlink()
        {
            location.replace("http://localhost/Assignment/Multipage/fileMaker.php");
            
        }
        
function plink()
        {
            location.replace("http://localhost/Assignment/Multipage/page3.php");
            
        }
</script>


 <?php
        
        if(isset($_COOKIE['hasValue'])) {
        	 $hasValue=json_decode($_COOKIE['hasValue'], true);
        }
        else {
        	$hasValue=0;
        }
        
        if(isset($_COOKIE['hasValue2'])) {
        	 $hasValue2=json_decode($_COOKIE['hasValue2'], true);
        }
        else {
        	$hasValue2=0;
        }
        
       
        if(isset($_COOKIE['hasValue3'])) {
        	 $hasValue3=json_decode($_COOKIE['hasValue3'], true);
        }
        else {
        	$hasValue3=0;
        }
       ?>
<body>
	<div class="">
		<h3>PASSPORT APPLICATION - REVIEW ENROLMENT SUMMARY</h3>
		<p style="color:#338099"><b>Online application ID: OA0000004008216</b></p>
		<p style="color:green">Enrolment date: 26/06/2018</p>
		<p><i><h5 style="color:red">Reminder before submitting your application.</h5></i></p>
        <ul>
        	<li>
        		<p><i>After you click submit,you are not allowed to modify your information.</i></p>
        	</li>
        	<li>
        		<p><i>Please visit <b>BAGERHAT Branch</b> on any working day within the next 15 days for biometric capture except government holidy.</i></p> 
        	</li>
        </ul> 
		<hr>
		<form action="" method="">
			<fieldset>
				<table style="width:50%; float:left;  border-spacing:8px;">
					<tr>
						<td><h3 style="color:#338099">Personal Information Summary</h3></td>
					</tr>
					<tr>
						<td>Name of Applicant:</td>
						<td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['name']==1) echo $_COOKIE['name'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>First Part(Given Name):</td>
						<td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['fName']==1) echo $_COOKIE['fName'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Second Part(Surname):</td>
						<td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['sName']==1) echo $_COOKIE['sName'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					
					<tr>
						<td>Gender:</td>
						<td>Male</td>
					</tr>
					<tr>
						<td>Nationality:</td>
						<td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['nationality']==1) echo $_COOKIE['nationality'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Date of Birth:</td>
						<td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['dob']==1) echo $_COOKIE['dob'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Place of Birth:</td>
						<td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['cob']==1) echo $_COOKIE['cob'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Father's Name:</td>
						<td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['faName']==1) echo $_COOKIE['faName'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Mother's Name:</td>
						<td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['mName']==1) echo $_COOKIE['mName'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Spouse's Name:</td>
						<td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['spName']==1) echo $_COOKIE['spName'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>National ID No:</td>
						<td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['nid']==1) echo $_COOKIE['nid'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Birth ID No:</td>
						<td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['bid']==1) echo $_COOKIE['bid'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Old Passport No:</td>
						<td><?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['emPassNo']==1) echo $_COOKIE['emPassNo'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>


				</table>

				<!-- 2nd table -->
				<table style="width:50%; float:left;  border-spacing:8px;">
					<tr>
						<td><h3 style="color:#338099">Passport Information Summary</h3></td>
					</tr>
					<tr>
						<td>Applying in:</td>
						<td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['applyin']==1) echo $_COOKIE['applyin'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Passport Type:</td>
						<td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['passType']==1) echo $_COOKIE['passType'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Application Type:</td>
						<td>NEW APPLICATION</td>
					</tr>
					<tr>
						<td><h3 style="color:#338099">Contact Information System</h3></td>
					</tr>
					<tr>
						<td>Mobile No:</td>
						<td><?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['pn']==1) echo $_COOKIE['pn'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Present Address:</td>
						<td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['pDist']==1) echo $_COOKIE['pVH']."," .$_COOKIE['pRoad']."," . $_COOKIE['pPST'].",". $_COOKIE['pPO'].", ". $_COOKIE['pDist'].","."Bangladesh.";
                                       else echo '';
                                       }
                                        else echo '';  ?> </td>
					</tr>
					<tr>
				        <td>Parmanent Address:</td>
				        <td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['paDist']==1) echo $_COOKIE['paVH']."," .$_COOKIE['paRoad']."," . $_COOKIE['paPST'].",". $_COOKIE['paPO'].", ". $_COOKIE['paDist'].","."Bangladesh.";
                                       else echo '';
                                       }
                                        else echo '';  ?> </td>
					</tr>
					<tr>
						<td>Email:</td>
						<td><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['email']==1) echo $_COOKIE['email'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td><h3 style="color:#338099">Payment Information Summary</h3></td>
					</tr>
					<tr>
						<td>Payment Amount:</td>
						<td><?php if($hasValue3!=0)
                                      {
                                      	if($hasValue3['money']==1) echo $_COOKIE['money'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Payment Date:</td>
						<td><?php if($hasValue3!=0)
                                      {
                                      	if($hasValue3['pDate']==1) echo $_COOKIE['pDate'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Receipt No:</td>
						<td><?php if($hasValue3!=0)
                                      {
                                      	if($hasValue3['reNo']==1) echo $_COOKIE['reNo'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Bank Name:</td>
						<td><?php if($hasValue3!=0)
                                      {
                                      	if($hasValue3['bank']==1) echo $_COOKIE['bank'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Bank Branch:</td>
						<td><?php if($hasValue3!=0)
                                      {
                                      	if($hasValue3['branch']==1) echo $_COOKIE['branch'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					
					<tr>
						<td><input type="button" name="previous-page" value="PREVIOUS PAGE" onclick="plink()"></td>
						<td><input type="button" name="save" value="SAVE" onclick="nlink()"></td>
					</tr>


				</table>
				<p style="color:red;"><b>Reminder:Bring old passport during collection of MRP;No correction after handover of delivery slip without fee.</b></p>
			</fieldset>
		</form>
	</div>
</body>
</html>