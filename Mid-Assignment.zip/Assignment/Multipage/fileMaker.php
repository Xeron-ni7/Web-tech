<script type="text/javascript">
function nlink()
        {
            location.replace("http://localhost/Assignment/Multipage/page1.php");
            
        }

function p2link()
        {
            location.replace("http://localhost/Assignment/Multipage/page2.php");
            
        }
        
function p3link()
        {
            location.replace("http://localhost/Assignment/Multipage/page3.php");
            
        }
</script>

<?php

$e1;
$e2;
$e3;


 if(isset($_COOKIE['fieldError']))
        {
          $e1=json_decode($_COOKIE['fieldError'],true);
          $i=count($e1);
          echo "<fieldset style='background-color:Gainsboro ;width:50%;margin-left:300px;' align='center'>";
          echo "<legend><font color='red'> Unfinished in page One</font></legend>";
          for($j=0;$j<$i;$j++)
          {
            echo "<font color='red'>*</font> $e1[$j] </br>";
          }
          
          echo"<input type='button' value='Go to Page 1' align='center' style='padding:5px;' onclick='nlink()'/>";
          echo "</fieldset>";
       }
          
          echo "</br>";    
          echo "</br>"; 
          
   if(isset($_COOKIE['fieldError2']))
        {
          $e2=json_decode($_COOKIE['fieldError2'],true);
          $i=count($e2);
         echo "<fieldset style='background-color:Gainsboro ;width:50%;margin-left:300px;' align='center'>";
            echo "<legend><font color='red'> Unfinished in page One</font></legend>";
          for($j=0;$j<$i;$j++)
          {
            echo "<font color='red'>*</font> $e2[$j] </br>";
          }
          
           echo"<input type='button' value='Go to Page 2' align='center' style='padding:5px;' onclick='p2link()'/>";
          echo "</fieldset>";
       }
    
     echo "</br>";    
     echo "</br>";   
    
    if(isset($_COOKIE['fieldError3']))
        {
          $e3=json_decode($_COOKIE['fieldError3'],true);
          $i=count($e3);
          echo "<fieldset style='background-color:Gainsboro ;width:50%;margin-left:300px;' align='center'>";
           echo "<legend><font color='red'> Unfinished in page One</font></legend>";
          for($j=0;$j<$i;$j++)
          {
            echo "<font color='red'>*</font> $e3[$j] </br>";
          }
           echo"<input type='button' value='Go to Page 3' align='center' style='padding:5px;' onclick='p3link()'/>";
          echo "</fieldset>";
       }
          
     if(empty($e1) && empty($e2) && empty($e3)) {
             	
             	$myfile = fopen("0101".$_COOKIE['name'].".txt", "wr") or die("Unable to open file!");
               $txt = "Name of Applicant: ".$_COOKIE['name']."\n";
               fwrite($myfile, $txt);
               
                $txt = "First Name: ".$_COOKIE['fName']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Surname: ".$_COOKIE['sName']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Nationality: ".$_COOKIE['nationality']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Profession: ".$_COOKIE['job']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Father\'s Name: ".$_COOKIE['faName']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Mother\'s Name: ".$_COOKIE['mName']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Present Address: ".$_COOKIE['pVH']."," .$_COOKIE['pRoad']."," . $_COOKIE['pPST'].",". $_COOKIE['pPO'].", ". $_COOKIE['pDist'].","."Bangladesh."."\n";
               fwrite($myfile, $txt);
               
                 $txt = "Permanent Address: ".$_COOKIE['paVH']."," .$_COOKIE['paRoad']."," . $_COOKIE['paPST'].",". $_COOKIE['paPO'].", ". $_COOKIE['paDist'].","."Bangladesh."."\n";
               fwrite($myfile, $txt);               
               
                $txt = "Birth id no: ".$_COOKIE['bid']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Passport Type: ".$_COOKIE['passType']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Mobile No: ".$_COOKIE['pn']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Email Address: ".$_COOKIE['email']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Payment Amount: ".$_COOKIE['money']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Payment Date: ".$_COOKIE['pDate']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Bank: ".$_COOKIE['bank']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Branch: ".$_COOKIE['branch']."\n";
               fwrite($myfile, $txt);
               fclose($myfile);
               
               echo"<h1 align='center'> <font color='DarkSlateGray'>Congratulation!!</font> Registration Successfully done...</h1>";
               echo"<input type='button' value='Exit' style='padding:5px;margin-left:600px;' onclick='nlink()'/>";
               
     	
     	}

?>