<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Passport Application Part-2</title>
	 <link rel="stylesheet" href="page_1_Style.css">
</head>
<script type="text/javascript">
 function limit(element)
{
    var max_chars = 8;
    var x=0;
    if(element.value.length > max_chars) {
        document.getElementById('ph').value=x;
        alert("please enter 8 digit only");
    }
   
}
        function nlink()
        {
            location.replace("http://localhost/Assignment/Multipage/page1.php");
            
        }
</script>
<body>
	
		<h3>PASSPORT APPLICATION - STAGE 2</h3>
		<p style="color:navy">Online application ID: OA0000004008216</p>
        <p>Fields marked with <span style="color:red">(*)</span> are mendatory.</p>
        <hr style="color:gray;">
           <!-----php code -->
        <?php
        if(isset($_COOKIE['fieldError2']))
        {
          $e=json_decode($_COOKIE['fieldError2'],true);
          $i=count($e);
         echo "<fieldset style='background-color:gray'>";
          for($j=0;$j<$i;$j++)
          {
            echo "<font color='red'>*</font> $e[$j] </br>";
          }
          echo "</fieldset>";
        }
        if(isset($_COOKIE['hasValue2'])) {
        	 $hasValue2=json_decode($_COOKIE['hasValue2'], true);
        }
        else {
        	$hasValue2=0;
        }
       ?>
        <!-- php code end here -->
        <form action="page-2-val.php" method="POST">
        <fieldset>
        	<table style="width:50%;float:left; border-right:2px dashed gray; border-spacing:8px;">
        		<tr>
        			<td><h4 style="color:darkseagreen;">Applicant Contact Information</h4></td>
           		</tr>
           		<tr>
           			<td>Office No.</td>
           			<td><input type="text" name="ofNo" value="<?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['ofNo']==1) echo $_COOKIE['ofNo'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
           		</tr>
           		<tr>
           			<td>Residence No:</td>
           			<td><input type="text" name="reNo" value="<?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['reNo']==1) echo $_COOKIE['reNo'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
           		</tr>
           		<tr>
           			<td>Mobile No.</td>
           			 <td>
                            <select name="nt" style="padding:5px; width:60px">
                                <option><?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['pd']==1) echo $_COOKIE['pd'];
                                       else echo '015';
                                       }
                                        else echo '015';  ?></option>
                                <option>016</option>
                                <option>017</option>
                                <option>018</option>
                                <option>019</option>
                            </select><input type="mNum" name="phoneNumber" value="<?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['ppn']==1) echo $_COOKIE['ppn'];
                                       else echo 0;
                                       }
                                        else echo 0;  ?>" max="99999999" id="ph" size="7" style="padding:5px;width:170px;border-radius:5px;" onkeyup="limit(this)" c></td>
           		</tr>
           		<tr>
           			<td><h4 style="color:navy">Emergency Contact Person's Details</h4></td>
           		</tr>
           		<tr>
           			<td>Name: <span style="color:red">*</span></td>
           			<td><input type="text" name="emName" value="<?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['emName']==1) echo $_COOKIE['emName'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
           		</tr>
           		<tr>
           			<td>Country: <span style="color:red">*</span></td>
           			<td>
           				<select name="emCountry">
						        <option selected>BANGLADESH</option> 
						        <option><?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['emCountry']==1) echo $_COOKIE['emCountry'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';?></option>
						        <option>UK</option>
						        <option>CANADA</option>
						        <option>PAKISTAN</option>
						        <option>INDIA</option>
						        <option>AUSTRALIA</option>
						        <option>THAILAND</option>
					        </select>
           			</td>
           		</tr>
           		<tr>
           			<td><input type="checkbox" name="sPer">  Same as permanent address</td>
           		</tr>
           		<tr>
           			<td><input type="checkbox" name="sPre">  Same as present address</td>
           		</tr>
           		<tr>
           			<td>Village/House:</td>
           			<td><input type="text" name="emVH" value="<?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['emVH']==1) echo $_COOKIE['emVH'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
           		</tr>
           		<tr>
           			<td>Road/Block/Sector:</td>
           			<td><input type="text" name="emRoad" value="<?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['emRoad']==1) echo $_COOKIE['emRoad'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
           		</tr>
           		<tr>
           			<td> District: <span style="color:red">*</span></td>
           			<td>
           				 <select name="emDist">
						            <option selected><?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['emDist']==1) echo $_COOKIE['emDist'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';?></option>
						            <option>DHAKA</option>
						            <option>CHITTAGONG</option>
						            <option>COMILLA</option>
						            <option>COX'S BAZAR</option>
						            <option>BORISHAL</option>
						            <option>KHULNA</option>
						            <option>SHYLET</option>
						            <option>NARIONGONGH</option>
			     	        </select>
           			</td>
                </tr>
                <tr>
                	<td> Police Station: <span style="color:red">*</span></td>
                	<td>
                		<select name="emPST" >
			     		            <option selected><?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['emPST']==1) echo $_COOKIE['emPST'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';?></option>
			     		            <option >Uttara</option>
			     		             <option>Banani</option>
			            </select>
                	</td>
                </tr>
                <tr>
                	<td>Post Office: <span style="color:red">*</span></td>
                	<td>
                		 <select name="emPO" value="">
			     		                <option selected><?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['emPO']==1) echo $_COOKIE['emPO'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';?></option>
			     		                <option>Banani</option>
			     	     </select>
                	</td>
                </tr>
                <tr>
                	<td>Contact No: <span style="color:red">*</span></td>
                	<td><input type="contact" name="emCon" value="<?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['emCon']==1) echo $_COOKIE['emCon'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
                </tr>
                <tr>
                	<td> Email: </td>
                	<td><input type="text" name="emEmail"  value="<?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['emEmail']==1) echo $_COOKIE['emEmail'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
                </tr>
                <tr>
                	<td>Relationship: <span style="color:red">*</span></td>
                	<td>
                		<select name="emRel"  >
			     	            	<option selected><?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['emRel']==1) echo $_COOKIE['emRel'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';?></option>
			     	            	<option>BROTHER</option>
			     	            	<option>SISTER</option>
			     	            	<option>UNCLE</option>
			     	     </select>
                	</td>
                </tr>
           </table>
        	<!-- 2nd Table Start-->
        	<table style="width:50%; float:left;  border-spacing:8px;">
        		<tr>
        			<td><h4 style="color:darkgreen" class="td1">Old Passport Information</h4></td>
        		</tr>
        		<tr>
        			<td><p class="td1">Passport No:</p></td>
        			<td><input type="text" name="emPassNo" value="<?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['emPassNo']==1) echo $_COOKIE['emPassNo'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
        		</tr>
        		<tr>
        			<td><p class="td1">Place of Issue:</p></td>
        			<td><input type="text" name="pIs" value="<?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['pIs']==1) echo $_COOKIE['pIs'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
        		</tr>
        		<tr>
        			<td><p class="td1">Date of Issue:</p></td>
        			<td><input type="date" name="dIs" value="<?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['dIs']==1) echo $_COOKIE['dIs'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
        		</tr>
        		<tr>
        			<td><p class="td1">Re-issue Reason:</p></td>
        			<td> 
        				<select name="rIs" >
			     	            	<option selected><?php if($hasValue2!=0)
                                      {
                                      	if($hasValue2['rIs']==1) echo $_COOKIE['rIs'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';?></option>
			     	            	<option></option>
			     	    </select>
			     	</td>
        		</tr>
        		<tr></tr>
        		<tr></tr>
        		<tr></tr>
        		<tr></tr>
        		<tr></tr>
        		<tr></tr>
        		<tr></tr>
             <tr>     <td colspan="2"align="center" >
                  <input type="button" style="margin-left:290px;" name="save" value="Previous Page" onclick="nlink()"/>
                  <input type="submit" name="submit" value="SAVE & NEXT" />           
                 </td></tr>
        	</table>
           
        </fieldset>    	
        </form>
	</div>
</body>
</html>