<html>
    <head>
        <title>
            page one
        </title>
        <link rel="stylesheet" href="page_1_Style.css">
    </head>
    <body>
        <h1>PASSPORT APPLICATION-STAGE 1</h1>
        <p style="color: red;margin-left: 15px;"><i>Before filling up the application form reas the guidelines carefully.</i></p>
        <p style="margin-left: 15px;">Fields marked with <i style="color: red">(*)</i> are mandatory.</p>
        <hr style="margin-left: 15px;">
        
        <!-----php code -->
        <?php
        if(isset($_COOKIE['fieldError']))
        {
          $e=json_decode($_COOKIE['fieldError'],true);
          $i=count($e);
          echo "<fieldset style='background-color:gray'>";
          for($j=0;$j<$i;$j++)
          {
            echo "<font color='red'>*</font> $e[$j] </br>";
          }
          echo "</fieldset>";
        }
        if(isset($_COOKIE['hasValue'])) {
        	 $hasValue=json_decode($_COOKIE['hasValue'], true);
        }
        else {
        	$hasValue=0;
        }
       ?>
        <!-- php code end here -->
        
        <!-- fieldset of form -->        
        <fieldset>
        <form action="page-1-val.php" method="POST">
        <table style="border-right-style: dashed;" >
        <tr>
            <td colspan="2"><h3 style="color: darkseagreen"  class="td1">Passport Application Information</h3> </td>
            
            
            </tr>
        <tr>
            <td><p class="td1">Applying in:<font color="red">*</font></p>
                
            <td><select name="applyin" >
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['applyin']==1) echo $_COOKIE['applyin'];
                                       else echo 'Bangladesh';
                                       }
                                        else echo 'Bangladesh';  ?></option>
                    <option>America</option>
                    <option>Brazil</option>
                    <option>Germany</option>
                    <option>India</option>
                </select></td>
            </tr>
            
        <tr>
            <td><p class="td1">Application Type:</p> </td>
            
            <td><b>NEW APPLICATION</b></td>
            </tr>
            
        <tr>
            <td><p class="td1">Passport Type: 
                </p></td>
            
            <td><select name="passType" >
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['passType']==1) echo $_COOKIE['passType'];
                                       else echo 'A';
                                       }
                                        else echo 'B';  ?></option>
                    <option>A</option>
                    <option>B</option>
                    <option>C</option>
                </select></td>
            </tr>
            
        <tr>
            <td><p class="td1">Delivery type:  </p> </td>
                                
            
            <td><input type="radio" name="delType" value="regular" >Regular<br>
                                 <input type="radio" name="delType" value="express">Express</td>
            </tr>
            
        <tr>
            <td colspan="2"><h3 style="color: darkseagreen" class="td1">Personal Information: </h3></td>
            
            </tr>
            
        <tr>
            <td><p class="td1">Name of<br>Applicant:<i style="color: red">*</i></p></td>
            
            <td><input type="text" name="name" value="<?php if($hasValue!=0)
                                      {
                                      	if($hasValue['name']==1) echo $_COOKIE['name'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
            </tr>
        <tr>
            <td><p class="td1">First Part(Given<br>Name:)<i style="color: red">*</i></p></td>
            
            <td><input type="text" name="fName" value="<?php if($hasValue!=0)
                                      {
                                      	if($hasValue['fName']==1) echo $_COOKIE['fName'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
            </tr>
        <tr>
            <td><p class="td1">Second Part<br>(Surname):<i style="color: red">*</i></p></td>
            
            <td><input type="text" name="sName" value="<?php if($hasValue!=0)
                                      {
                                      	if($hasValue['sName']==1) echo $_COOKIE['sName'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
            </tr>
        <tr>
            <td><p class="td1">Father's Name:<i style="color: red">*</i></p></td>
            
            <td><input type="text" name="faName" value="<?php if($hasValue!=0)
                                      {
                                      	if($hasValue['faName']==1) echo $_COOKIE['faName'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
            </tr>
        <tr>
            <td><p class="td1">Father's<br>Nationality:<i style="color: red">*</i></p></td>
            
            <td><select name="faNationality" value="Bangladesh">
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['faNationality']==1) echo $_COOKIE['faNationality'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                    <option>America</option>
                    <option>Bangladesh</option>
                    <option>Brasil</option>
                    <option>Germany</option>
                    <option>India</option>
                </select></td>
            </tr>
       <tr>
           <td><p class="td1">Father's<br>Profession:<i style="color: red">*</i></p></td>
            
            <td><select name="fajob" value="Bangladesh">
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['fajob']==1) echo $_COOKIE['fajob'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                    <option>Teacher</option>
                    <option>Govt. Officer</option>
                    <option>Scientist</option>
                    <option>Retired</option>
                </select></td>
            </tr>
         <tr>
             <td><p class="td1">Mother's Name:<i style="color: red">*</i></p></td>
            
            <td><input type="text" name="mName" value="<?php if($hasValue!=0)
                                      {
                                      	if($hasValue['mName']==1) echo $_COOKIE['mName'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
            </tr>
        <tr>
            <td><p class="td1">Mother's<br>Nationality:<i style="color: red">*</i></p></td>
            
            <td><select name="mNationality" value="Bangladesh">
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['mNationality']==1) echo $_COOKIE['mNationality'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                    <option>America</option>
                    <option>Bangladesh</option>
                    <option>Brasil</option>
                    <option>Germany</option>
                    <option>India</option>
                </select></td>
            </tr>
       <tr>
           <td><p class="td1">Mother's<br>Profession:<i style="color: red">*</i></p></td>
            
            <td><select name="mjob" value="Bangladesh">
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['mjob']==1) echo $_COOKIE['mjob'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                    <option>House Wife</option>
                    <option>Teacher</option>
                    <option>Doctor</option>
                    <option>Govt. Officer</option>
                </select></td>
            </tr>
         <tr>
             <td><p class="td1">Spouse's Name:</p></td>
            
            <td><input type="text" name="spName" value="<?php if($hasValue!=0)
                                      {
                                      	if($hasValue['spName']==1) echo $_COOKIE['spName'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
            </tr>
        <tr>
            <td><p class="td1">Spouse's<br>Nationality:</p></td>
            
            <td><select name="spNationality" value="Bangladesh">
                     <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['spNationality']==1) echo $_COOKIE['spNationality'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>                    
                    <option>America</option>
                    <option>Bangladesh</option>
                    <option>Brasil</option>
                    <option>Germany</option>
                    <option>India</option>
                </select></td>
            </tr>
       <tr>
           <td><p class="td1">Spouse's<br>Profession:</p></td>
            
            <td><select name="spjob" value="Bangladesh">
                     <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['spjob']==1) echo $_COOKIE['spjob'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                    <option>House Wife</option>
                    <option>Teacher</option>
                    <option>Doctor</option>
                    <option>Govt. Officer</option>
                    <option>Retired</option>
                </select></td>
            </tr>
         <tr>
             <td><p class="td1">Mrital Status:<i style="color: red">*</i></p></td>
            
            <td><select name="mStatus" value="Bangladesh">
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['mStatus']==1) echo $_COOKIE['mStatus'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                    <option>Married</option>
                    <option>Unmarried</option>
                   
                </select></td>
            </tr>
         <tr>
             <td><p class="td1">Applicant's<br>Profession:<i style="color: red">*</i></p></td>
            
            <td><select name="job" value="Bangladesh">
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['job']==1) echo $_COOKIE['job'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                    <option>Teacher</option>
                    <option>Govt. Officer</option>
                    <option>Scientist</option>
                    <option>Retired</option>
                    <option>Doctor</option>
                </select></td>
            </tr>
         <tr>
             <td><p class="td1">Country of<br>Birth:<i style="color: red">*</i></p></td>
            
            <td><select name="cob" value="Bangladesh">
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['cob']==1) echo $_COOKIE['cob'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                    <option>Bangladesh</option>
                    <option>Brasil</option>
                    <option>Germany</option>
                    <option>India</option>
                </select></td>
            </tr>
         <tr>
             <td><p class="td1">Birth District:<i style="color: red">*</i></p></td>
            
            <td><select name="bdist" value="Bangladesh">
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['bdist']==1) echo $_COOKIE['bdist'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                    <option>Bangladesh</option>
                    <option>Brasil</option>
                    <option>Germany</option>
                    <option>India</option>
                </select></td>
            </tr>
        </table>
        
        
        
        
        <!--Second Table -->



        
        <table style="margin-left: 53%;margin-top: -1225px;border-left: 0px">
        <tr>
            <td ><p class="td1">Date of birth:</p> </td>
            
            <td>  <input type="date" name="dob" value="<?php if($hasValue!=0)
                                      {
                                      	if($hasValue['dob']==1) echo $_COOKIE['dob'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
            </tr>
        <tr>
            <td><p class="td1">Gender:<font color="red">*</font></p>
                
            <td> <input type="radio" name="gender" value="Male" >Male <br>
                  <input type="radio" name="gender" value="Female" >Female<br>
                   <input type="radio" name="gender" value="other" >Other
            </td>
            </tr>
            
        <tr>
              <td><p class="td1">Birth ID No:<i style="color: red">*</i></p></td>
            
            <td><input type="text" name="bid" value="<?php if($hasValue!=0)
                                      {
                                      	if($hasValue['bid']==1) echo $_COOKIE['bid'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
            
        <tr>
           <td><p class="td1">National ID No.</p></td>
            
            <td><input type="text" name="nid" value="<?php if($hasValue!=0)
                                      {
                                      	if($hasValue['nid']==1) echo $_COOKIE['nid'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
            </tr>
            
        <tr>
           <td><p class="td1">Tax ID No:<i style="color: red">*</i></p></td>
            
            <td><input type="text" name="tid" value="<?php if($hasValue!=0)
                                      {
                                      	if($hasValue['tid']==1) echo $_COOKIE['tid'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
            </tr>
            
        <tr>
          <td><p class="td1">Height:<i style="color: red">*</i></p></td>
            
            <td><input type="text" name="cm" value="" >&nbsp cm
                <input type="text" name="inch" value="" >&nbsp inch</td>
            
            </tr>
            
        <tr>
            <td><p class="td1">Religion:<i style="color: red">*</i></p></td>
            
            <td><select name="religion" value="Bangladesh">
                     <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['religion']==1) echo $_COOKIE['religion'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                    <option>Islam</option>
                    <option>Hindu</option>
                    <option>Baddha</option>
                    <option>Cristian</option>
                </select></td>
            </tr>
        <tr>
            <td><p class="td1">Email:<i style="color: red">*</i></p></td>
            
            <td><input type="text" name="email" value="<?php if($hasValue!=0)
                                      {
                                      	if($hasValue['email']==1) echo $_COOKIE['email'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
            </tr>
        <tr>
            <td colspan="2"><h3 style="color: darkseagreen" class="td1">Citizenship Information: </h3></td>
            </tr>
        <tr>
            <td><p class="td1">Nationality:<i style="color: red">*</i></p></td>
            
            <td><select name="nationality" value="Bangladesh">
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['nationality']==1) echo $_COOKIE['nationality'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                    <option>Bangladesh</option>
                    <option>Brasil</option>
                    <option>Germany</option>
                    <option>India</option>
                </select></td>
            </tr>
        <tr>
            <td><p class="td1">Citizenship status:<i style="color: red">*</i></p></td>
            
            <td><select name="ctStatus" value="Bangladesh">
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['ctStatus']==1) echo $_COOKIE['ctStatus'];
                                       else echo 'Birth';
                                       }
                                        else echo 'Birth';  ?></option>
                    <option>Resident</option>
                    
                </select></td>
            </tr>
       <tr>
            <td><p class="td1">Dual Citizenship:<font color="red">*</font></p>
                
            <td> <input type="radio" name="dualct" value="none" >Yes <br>
                  <input type="radio" name="dualct" value="none" >No
            </tr>
         <tr>
            <td colspan="2"><h3 style="color: darkseagreen" class="td1">Present Address: </h3></td>
            </tr>
        <tr>
        <tr>
            <td><p class="td1">Village/House:<i style="color: red">*</i></p></td>
            
            <td><input type="text" name="pVH" value="<?php if($hasValue!=0)
                                      {
                                      	if($hasValue['pVH']==1) echo $_COOKIE['pVH'];
                                       else echo '';
                                       }
                                        else echo '';  ?>" class="input"></td>
            </tr>
       <tr>
            <td><p class="td1">Road/Block/Sector:<i style="color: red">*</i></p></td>
            
            <td><input type="text" name="pRoad" value="<?php if($hasValue!=0)
                                      {
                                      	if($hasValue['pRoad']==1) echo $_COOKIE['pRoad'];
                                       else echo '';
                                       }
                                        else echo '';  ?>"  class="input"></td>
            </tr>
         <tr>
            <td><p class="td1">District:<font color="red">*</font></p></td>
            
            <td><select name="pDist" value="-SELECT-">
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['pDist']==1) echo $_COOKIE['pDist'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?> </option>
                    <option>Dhaka</option>
                    <option>Chittagong</option>
                    <option>Barishal</option>
                    <option>Shyllet</option>
                </select></td>
            </tr>
        <tr>
            <td><p class="td1">Police station:</p></td>
            
            <td><select name="pPST" value="Bangladesh">
                     <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['pPST']==1) echo $_COOKIE['pPST'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?> </option>
                    <option>A</option>
                    <option>B</option>
                    <option>B</option>
                    <option>c</option>
                    <option>d</option>
                </select></td>
            </tr>
       <tr>
           <td><p class="td1">Police Office:</p></td>
            
            <td><select name="pPO" value="-SELECT-">
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['pPO']==1) echo $_COOKIE['pPO'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                </select></td>
            </tr>
         <tr>
            <td colspan="2"><h3 style="color: darkseagreen" class="td1">Permanent Address: </h3></td>
            </tr>
        <tr>
        <tr>
            <td><p class="td1">Village/House:<i style="color: red">*</i></p></td>
            
            <td><input type="text" name="paVH" value="<?php if($hasValue!=0)
                                      {
                                      	if($hasValue['paVH']==1) echo $_COOKIE['paVH'];
                                       else echo '';
                                       }
                                        else echo '';  ?> " class="input"></td>
            </tr>
       <tr>
            <td><p class="td1">Road/Block/Sector:<i style="color: red">*</i></p></td>
            
            <td><input type="text" name="paRoad" value="<?php if($hasValue!=0)
                                      {
                                      	if($hasValue['paRoad']==1) echo $_COOKIE['paRoad'];
                                       else echo '';
                                       }
                                        else echo '';  ?>"  class="input"></td>
            </tr>
         <tr>
            <td><p class="td1">District:<font color="red">*</font></p></td>
            
            <td><select name="paDist" value="-SELECT-">
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['paDist']==1) echo $_COOKIE['paDist'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                    <option>Dhaka</option>
                    <option>Chittagong</option>
                    <option>Barishal</option>
                    <option>Shyllet</option>
                </select></td>
            </tr>
        <tr>
            <td><p class="td1">Police station:</p></td>
            
            <td><select name="paPST" value="">
                   <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['paPST']==1) echo $_COOKIE['paPST'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                    <option>A</option>
                    <option>B</option>
                    <option>B</option>
                    <option>c</option>
                    <option>d</option>
                </select></td>
            </tr>
       <tr>
           <td><p class="td1">Police Office:</p></td>
            
            <td><select name="paPO" value="-SELECT-">
                    <option><?php if($hasValue!=0)
                                      {
                                      	if($hasValue['paPO']==1) echo $_COOKIE['paPO'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                </select></td>
            </tr>
            <tr>
            <td colspan="2"align="center">
            <input type="button" style="margin-left:90px;" name="save" value="SAVE NOW & CONTINUE IN THE FUTURE"/>
            <input type="submit" name="submit" value="SAVE & NEXT" />
               </td>
               </tr>
        </table>
        </form>
        </fieldset>
    </body>
</html>