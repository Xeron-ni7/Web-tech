
<!DOCTYPE html>
<html>
<head>
	<title>
		Frequency counter
	</title>
</head>
<body>
	<hr style="color: grey;,margin-top:20px">
	<h2 style="margin-top:3px;,text-align:center;"> Character Frequency</h2>
	<hr style="color:grey; ">
	<p>Insert your string to get count per character</p>
	<form action="Frequencyshow.php" name="frequencyCounter" method="post" >
		<textarea rows="4" cols="50" name="v1" ></textarea>
		<input type="submit" value="submit">
	</form>

</body>
</html>